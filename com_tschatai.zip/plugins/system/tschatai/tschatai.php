<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Document\HtmlDocument;

class PlgSystemTschatai extends CMSPlugin
{
    protected $app;
    
    public function onBeforeCompileHead()
    {
        if ($this->app->isClient('site')) {
            $document = $this->app->getDocument();
            
            if ($document instanceof HtmlDocument) {
                $wa = $document->getWebAssetManager();
                $wa->getRegistry()->addRegistryFile('media/com_tschatai/joomla.asset.json');
                $wa->registerAndUseStyle('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
                $wa->useStyle('com_tschatai.chat')
                   ->useScript('com_tschatai.chat');
            }
        }
    }

    public function onBeforeRender()
    {
        if ($this->app->isClient('site')) {
            $buffer = $this->app->getBody();
            $buffer = str_replace('</body>', '<div id="ts-chat-container"></div></body>', $buffer);
            $this->app->setBody($buffer);
        }
    }
}