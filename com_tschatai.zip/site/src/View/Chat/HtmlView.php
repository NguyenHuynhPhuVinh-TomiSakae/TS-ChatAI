<?php
namespace YourNamespace\Component\TSChatAI\Site\View\Chat;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
    public function display($tpl = null)
    {
        return parent::display($tpl);
    }
} 