<?php
namespace YourNamespace\Component\TSChatAI\Site\Extension;

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Extension\MVCComponent;

class TSChatAIComponent extends MVCComponent
{
    // Có thể thêm các phương thức tùy chỉnh ở đây
} 