<?php
defined('_JEXEC') or die;
?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h2>TS-ChatAI Dashboard</h2>
                <p>Welcome to TS-ChatAI administration panel.</p>
                
                <div class="alert alert-info">
                    <h4>Tính năng:</h4>
                    <ul>
                        <li>Tích hợp ChatAI vào website</li>
                        <li>Tùy chỉnh giao diện chat</li>
                        <li>Quản lý lịch sử chat</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div> 