<?php
namespace YourNamespace\Component\TSChatAI\Administrator\Extension;

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Extension\MVCComponent;

class TSChatAIComponent extends MVCComponent
{
    // Có thể thêm các phương thức tùy chỉnh ở đây
} 